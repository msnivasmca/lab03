﻿IF OBJECT_ID(N'__EFMigrationsHistory') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;

GO

CREATE TABLE [AspNetRoles] (
    [Id] nvarchar(450) NOT NULL,
    [ConcurrencyStamp] nvarchar(max) NULL,
    [Name] nvarchar(256) NULL,
    [NormalizedName] nvarchar(256) NULL,
    CONSTRAINT [PK_AspNetRoles] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [AspNetUsers] (
    [Id] nvarchar(450) NOT NULL,
    [AccessFailedCount] int NOT NULL,
    [ConcurrencyStamp] nvarchar(max) NULL,
    [Email] nvarchar(256) NULL,
    [EmailConfirmed] bit NOT NULL,
    [LockoutEnabled] bit NOT NULL,
    [LockoutEnd] datetimeoffset NULL,
    [NormalizedEmail] nvarchar(256) NULL,
    [NormalizedUserName] nvarchar(256) NULL,
    [PasswordHash] nvarchar(max) NULL,
    [PhoneNumber] nvarchar(max) NULL,
    [PhoneNumberConfirmed] bit NOT NULL,
    [SecurityStamp] nvarchar(max) NULL,
    [TwoFactorEnabled] bit NOT NULL,
    [UserName] nvarchar(256) NULL,
    CONSTRAINT [PK_AspNetUsers] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [Bill] (
    [BillId] int NOT NULL IDENTITY,
    [BillDate] datetimeoffset NOT NULL,
    [BillDueDate] datetimeoffset NOT NULL,
    [BillName] nvarchar(max) NULL,
    [BillTypeId] int NOT NULL,
    [GoodsReceivedNoteId] int NOT NULL,
    [VendorDONumber] nvarchar(max) NULL,
    [VendorInvoiceNumber] nvarchar(max) NULL,
    CONSTRAINT [PK_Bill] PRIMARY KEY ([BillId])
);

GO

CREATE TABLE [BillType] (
    [BillTypeId] int NOT NULL IDENTITY,
    [BillTypeName] nvarchar(max) NOT NULL,
    [Description] nvarchar(max) NULL,
    CONSTRAINT [PK_BillType] PRIMARY KEY ([BillTypeId])
);

GO

CREATE TABLE [Branch] (
    [BranchId] int NOT NULL IDENTITY,
    [Address] nvarchar(max) NULL,
    [BranchName] nvarchar(max) NOT NULL,
    [City] nvarchar(max) NULL,
    [ContactPerson] nvarchar(max) NULL,
    [CurrencyId] int NOT NULL,
    [Description] nvarchar(max) NULL,
    [Email] nvarchar(max) NULL,
    [Phone] nvarchar(max) NULL,
    [State] nvarchar(max) NULL,
    [ZipCode] nvarchar(max) NULL,
    CONSTRAINT [PK_Branch] PRIMARY KEY ([BranchId])
);

GO

CREATE TABLE [CashBank] (
    [CashBankId] int NOT NULL IDENTITY,
    [CashBankName] nvarchar(max) NULL,
    [Description] nvarchar(max) NULL,
    CONSTRAINT [PK_CashBank] PRIMARY KEY ([CashBankId])
);

GO

CREATE TABLE [Currency] (
    [CurrencyId] int NOT NULL IDENTITY,
    [CurrencyCode] nvarchar(max) NOT NULL,
    [CurrencyName] nvarchar(max) NOT NULL,
    [Description] nvarchar(max) NULL,
    CONSTRAINT [PK_Currency] PRIMARY KEY ([CurrencyId])
);

GO

CREATE TABLE [Customer] (
    [CustomerId] int NOT NULL IDENTITY,
    [Address] nvarchar(max) NULL,
    [City] nvarchar(max) NULL,
    [ContactPerson] nvarchar(max) NULL,
    [CustomerName] nvarchar(max) NOT NULL,
    [CustomerTypeId] int NOT NULL,
    [Email] nvarchar(max) NULL,
    [Phone] nvarchar(max) NULL,
    [State] nvarchar(max) NULL,
    [ZipCode] nvarchar(max) NULL,
    CONSTRAINT [PK_Customer] PRIMARY KEY ([CustomerId])
);

GO

CREATE TABLE [CustomerType] (
    [CustomerTypeId] int NOT NULL IDENTITY,
    [CustomerTypeName] nvarchar(max) NOT NULL,
    [Description] nvarchar(max) NULL,
    CONSTRAINT [PK_CustomerType] PRIMARY KEY ([CustomerTypeId])
);

GO

CREATE TABLE [GoodsReceivedNote] (
    [GoodsReceivedNoteId] int NOT NULL IDENTITY,
    [GRNDate] datetimeoffset NOT NULL,
    [GoodsReceivedNoteName] nvarchar(max) NULL,
    [IsFullReceive] bit NOT NULL,
    [PurchaseOrderId] int NOT NULL,
    [VendorDONumber] nvarchar(max) NULL,
    [VendorInvoiceNumber] nvarchar(max) NULL,
    [WarehouseId] int NOT NULL,
    CONSTRAINT [PK_GoodsReceivedNote] PRIMARY KEY ([GoodsReceivedNoteId])
);

GO

CREATE TABLE [Invoice] (
    [InvoiceId] int NOT NULL IDENTITY,
    [InvoiceDate] datetimeoffset NOT NULL,
    [InvoiceDueDate] datetimeoffset NOT NULL,
    [InvoiceName] nvarchar(max) NULL,
    [InvoiceTypeId] int NOT NULL,
    [ShipmentId] int NOT NULL,
    CONSTRAINT [PK_Invoice] PRIMARY KEY ([InvoiceId])
);

GO

CREATE TABLE [InvoiceType] (
    [InvoiceTypeId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [InvoiceTypeName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_InvoiceType] PRIMARY KEY ([InvoiceTypeId])
);

GO

CREATE TABLE [NumberSequence] (
    [NumberSequenceId] int NOT NULL IDENTITY,
    [LastNumber] int NOT NULL,
    [Module] nvarchar(max) NOT NULL,
    [NumberSequenceName] nvarchar(max) NOT NULL,
    [Prefix] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_NumberSequence] PRIMARY KEY ([NumberSequenceId])
);

GO

CREATE TABLE [PaymentReceive] (
    [PaymentReceiveId] int NOT NULL IDENTITY,
    [InvoiceId] int NOT NULL,
    [IsFullPayment] bit NOT NULL,
    [PaymentAmount] float NOT NULL,
    [PaymentDate] datetimeoffset NOT NULL,
    [PaymentReceiveName] nvarchar(max) NULL,
    [PaymentTypeId] int NOT NULL,
    CONSTRAINT [PK_PaymentReceive] PRIMARY KEY ([PaymentReceiveId])
);

GO

CREATE TABLE [PaymentType] (
    [PaymentTypeId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [PaymentTypeName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_PaymentType] PRIMARY KEY ([PaymentTypeId])
);

GO

CREATE TABLE [PaymentVoucher] (
    [PaymentvoucherId] int NOT NULL IDENTITY,
    [BillId] int NOT NULL,
    [CashBankId] int NOT NULL,
    [IsFullPayment] bit NOT NULL,
    [PaymentAmount] float NOT NULL,
    [PaymentDate] datetimeoffset NOT NULL,
    [PaymentTypeId] int NOT NULL,
    [PaymentVoucherName] nvarchar(max) NULL,
    CONSTRAINT [PK_PaymentVoucher] PRIMARY KEY ([PaymentvoucherId])
);

GO

CREATE TABLE [Product] (
    [ProductId] int NOT NULL IDENTITY,
    [Barcode] nvarchar(max) NULL,
    [BranchId] int NOT NULL,
    [CurrencyId] int NOT NULL,
    [DefaultBuyingPrice] float NOT NULL,
    [DefaultSellingPrice] float NOT NULL,
    [Description] nvarchar(max) NULL,
    [ProductCode] nvarchar(max) NULL,
    [ProductImageUrl] nvarchar(max) NULL,
    [ProductName] nvarchar(max) NOT NULL,
    [UnitOfMeasureId] int NOT NULL,
    CONSTRAINT [PK_Product] PRIMARY KEY ([ProductId])
);

GO

CREATE TABLE [ProductType] (
    [ProductTypeId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [ProductTypeName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_ProductType] PRIMARY KEY ([ProductTypeId])
);

GO

CREATE TABLE [PurchaseOrder] (
    [PurchaseOrderId] int NOT NULL IDENTITY,
    [Amount] float NOT NULL,
    [BranchId] int NOT NULL,
    [CurrencyId] int NOT NULL,
    [DeliveryDate] datetimeoffset NOT NULL,
    [Discount] float NOT NULL,
    [Freight] float NOT NULL,
    [OrderDate] datetimeoffset NOT NULL,
    [PurchaseOrderName] nvarchar(max) NULL,
    [PurchaseTypeId] int NOT NULL,
    [Remarks] nvarchar(max) NULL,
    [SubTotal] float NOT NULL,
    [Tax] float NOT NULL,
    [Total] float NOT NULL,
    [VendorId] int NOT NULL,
    CONSTRAINT [PK_PurchaseOrder] PRIMARY KEY ([PurchaseOrderId])
);

GO

CREATE TABLE [PurchaseType] (
    [PurchaseTypeId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [PurchaseTypeName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_PurchaseType] PRIMARY KEY ([PurchaseTypeId])
);

GO

CREATE TABLE [SalesOrder] (
    [SalesOrderId] int NOT NULL IDENTITY,
    [Amount] float NOT NULL,
    [BranchId] int NOT NULL,
    [CurrencyId] int NOT NULL,
    [CustomerId] int NOT NULL,
    [CustomerRefNumber] nvarchar(max) NULL,
    [DeliveryDate] datetimeoffset NOT NULL,
    [Discount] float NOT NULL,
    [Freight] float NOT NULL,
    [OrderDate] datetimeoffset NOT NULL,
    [Remarks] nvarchar(max) NULL,
    [SalesOrderName] nvarchar(max) NULL,
    [SalesTypeId] int NOT NULL,
    [SubTotal] float NOT NULL,
    [Tax] float NOT NULL,
    [Total] float NOT NULL,
    CONSTRAINT [PK_SalesOrder] PRIMARY KEY ([SalesOrderId])
);

GO

CREATE TABLE [SalesType] (
    [SalesTypeId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [SalesTypeName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_SalesType] PRIMARY KEY ([SalesTypeId])
);

GO

CREATE TABLE [Shipment] (
    [ShipmentId] int NOT NULL IDENTITY,
    [IsFullShipment] bit NOT NULL,
    [SalesOrderId] int NOT NULL,
    [ShipmentDate] datetimeoffset NOT NULL,
    [ShipmentName] nvarchar(max) NULL,
    [ShipmentTypeId] int NOT NULL,
    [WarehouseId] int NOT NULL,
    CONSTRAINT [PK_Shipment] PRIMARY KEY ([ShipmentId])
);

GO

CREATE TABLE [ShipmentType] (
    [ShipmentTypeId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [ShipmentTypeName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_ShipmentType] PRIMARY KEY ([ShipmentTypeId])
);

GO

CREATE TABLE [UnitOfMeasure] (
    [UnitOfMeasureId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [UnitOfMeasureName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_UnitOfMeasure] PRIMARY KEY ([UnitOfMeasureId])
);

GO

CREATE TABLE [UserProfile] (
    [UserProfileId] int NOT NULL IDENTITY,
    [ApplicationUserId] nvarchar(max) NULL,
    [ConfirmPassword] nvarchar(max) NULL,
    [Email] nvarchar(max) NULL,
    [FirstName] nvarchar(max) NULL,
    [LastName] nvarchar(max) NULL,
    [OldPassword] nvarchar(max) NULL,
    [Password] nvarchar(max) NULL,
    CONSTRAINT [PK_UserProfile] PRIMARY KEY ([UserProfileId])
);

GO

CREATE TABLE [Vendor] (
    [VendorId] int NOT NULL IDENTITY,
    [Address] nvarchar(max) NULL,
    [City] nvarchar(max) NULL,
    [ContactPerson] nvarchar(max) NULL,
    [Email] nvarchar(max) NULL,
    [Phone] nvarchar(max) NULL,
    [State] nvarchar(max) NULL,
    [VendorName] nvarchar(max) NOT NULL,
    [VendorTypeId] int NOT NULL,
    [ZipCode] nvarchar(max) NULL,
    CONSTRAINT [PK_Vendor] PRIMARY KEY ([VendorId])
);

GO

CREATE TABLE [VendorType] (
    [VendorTypeId] int NOT NULL IDENTITY,
    [Description] nvarchar(max) NULL,
    [VendorTypeName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_VendorType] PRIMARY KEY ([VendorTypeId])
);

GO

CREATE TABLE [Warehouse] (
    [WarehouseId] int NOT NULL IDENTITY,
    [BranchId] int NOT NULL,
    [Description] nvarchar(max) NULL,
    [WarehouseName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_Warehouse] PRIMARY KEY ([WarehouseId])
);

GO

CREATE TABLE [AspNetRoleClaims] (
    [Id] int NOT NULL IDENTITY,
    [ClaimType] nvarchar(max) NULL,
    [ClaimValue] nvarchar(max) NULL,
    [RoleId] nvarchar(450) NOT NULL,
    CONSTRAINT [PK_AspNetRoleClaims] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [AspNetRoles] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [AspNetUserClaims] (
    [Id] int NOT NULL IDENTITY,
    [ClaimType] nvarchar(max) NULL,
    [ClaimValue] nvarchar(max) NULL,
    [UserId] nvarchar(450) NOT NULL,
    CONSTRAINT [PK_AspNetUserClaims] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [AspNetUserLogins] (
    [LoginProvider] nvarchar(450) NOT NULL,
    [ProviderKey] nvarchar(450) NOT NULL,
    [ProviderDisplayName] nvarchar(max) NULL,
    [UserId] nvarchar(450) NOT NULL,
    CONSTRAINT [PK_AspNetUserLogins] PRIMARY KEY ([LoginProvider], [ProviderKey]),
    CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [AspNetUserRoles] (
    [UserId] nvarchar(450) NOT NULL,
    [RoleId] nvarchar(450) NOT NULL,
    CONSTRAINT [PK_AspNetUserRoles] PRIMARY KEY ([UserId], [RoleId]),
    CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [AspNetRoles] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [AspNetUserTokens] (
    [UserId] nvarchar(450) NOT NULL,
    [LoginProvider] nvarchar(450) NOT NULL,
    [Name] nvarchar(450) NOT NULL,
    [Value] nvarchar(max) NULL,
    CONSTRAINT [PK_AspNetUserTokens] PRIMARY KEY ([UserId], [LoginProvider], [Name]),
    CONSTRAINT [FK_AspNetUserTokens_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);

GO

CREATE TABLE [PurchaseOrderLine] (
    [PurchaseOrderLineId] int NOT NULL IDENTITY,
    [Amount] float NOT NULL,
    [Description] nvarchar(max) NULL,
    [DiscountAmount] float NOT NULL,
    [DiscountPercentage] float NOT NULL,
    [Price] float NOT NULL,
    [ProductId] int NOT NULL,
    [PurchaseOrderId] int NOT NULL,
    [Quantity] float NOT NULL,
    [SubTotal] float NOT NULL,
    [TaxAmount] float NOT NULL,
    [TaxPercentage] float NOT NULL,
    [Total] float NOT NULL,
    CONSTRAINT [PK_PurchaseOrderLine] PRIMARY KEY ([PurchaseOrderLineId]),
    CONSTRAINT [FK_PurchaseOrderLine_PurchaseOrder_PurchaseOrderId] FOREIGN KEY ([PurchaseOrderId]) REFERENCES [PurchaseOrder] ([PurchaseOrderId]) ON DELETE CASCADE
);

GO

CREATE TABLE [SalesOrderLine] (
    [SalesOrderLineId] int NOT NULL IDENTITY,
    [Amount] float NOT NULL,
    [Description] nvarchar(max) NULL,
    [DiscountAmount] float NOT NULL,
    [DiscountPercentage] float NOT NULL,
    [Price] float NOT NULL,
    [ProductId] int NOT NULL,
    [Quantity] float NOT NULL,
    [SalesOrderId] int NOT NULL,
    [SubTotal] float NOT NULL,
    [TaxAmount] float NOT NULL,
    [TaxPercentage] float NOT NULL,
    [Total] float NOT NULL,
    CONSTRAINT [PK_SalesOrderLine] PRIMARY KEY ([SalesOrderLineId]),
    CONSTRAINT [FK_SalesOrderLine_SalesOrder_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrder] ([SalesOrderId]) ON DELETE CASCADE
);

GO

CREATE INDEX [IX_AspNetRoleClaims_RoleId] ON [AspNetRoleClaims] ([RoleId]);

GO

CREATE UNIQUE INDEX [RoleNameIndex] ON [AspNetRoles] ([NormalizedName]) WHERE [NormalizedName] IS NOT NULL;

GO

CREATE INDEX [IX_AspNetUserClaims_UserId] ON [AspNetUserClaims] ([UserId]);

GO

CREATE INDEX [IX_AspNetUserLogins_UserId] ON [AspNetUserLogins] ([UserId]);

GO

CREATE INDEX [IX_AspNetUserRoles_RoleId] ON [AspNetUserRoles] ([RoleId]);

GO

CREATE INDEX [EmailIndex] ON [AspNetUsers] ([NormalizedEmail]);

GO

CREATE UNIQUE INDEX [UserNameIndex] ON [AspNetUsers] ([NormalizedUserName]) WHERE [NormalizedUserName] IS NOT NULL;

GO

CREATE INDEX [IX_PurchaseOrderLine_PurchaseOrderId] ON [PurchaseOrderLine] ([PurchaseOrderId]);

GO

CREATE INDEX [IX_SalesOrderLine_SalesOrderId] ON [SalesOrderLine] ([SalesOrderId]);

GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20180809031729_initialdb', N'2.0.3-rtm-10026');

GO

ALTER TABLE [UserProfile] ADD [ProfilePicture] nvarchar(max) NULL;

GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20180810002948_profilepicture', N'2.0.3-rtm-10026');

GO

